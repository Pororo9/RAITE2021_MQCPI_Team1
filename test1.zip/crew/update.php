<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization, X-Requested-With");
// include database and object files
include_once '../config/database.php';
include_once '../objects/faculty.php';
// get database connection
$database = new Database();
$db = $database->getConnection();
// prepare Faculty object
$Faculty = new Faculty($db);
// get Faculty_ID of Faculty to be edited
$data = json_decode(file_get_contents("php://input"));
// set Faculty_ID property of Faculty to be edited
$Faculty->Emp_ID = $data->Emp_ID;
// set Faculty property values
$Faculty->L_Name = $data->L_Name;
$Faculty->F_Name = $data->F_Name;
$Faculty->M_Name = $data->M_Name;
$Faculty->Gender = $data->Gender;
$Faculty->Dept_Code = $data->Dept_Code;
$Faculty->Email = $data->Email;
// update the Faculty
if($Faculty->update()){
 // set response code - 200 ok
 http_response_code(200);
 // tell the user
 echo json_encode(array("message" => "Employee was updated."));
}
// if unable to update the Faculty, tell the user
else{
 // set response code - 503 service unavailable
 http_response_code(503);
 // tell the user
 echo json_encode(array("message" => "Unable to update Employee."));
}
?>