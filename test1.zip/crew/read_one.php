<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Allow-Credentials: true");
header('Content-Type: application/json');
// include database and object files
include_once '../config/database.php';
include_once '../objects/faculty.php';
// get database connection
$database = new Database();
$db = $database->getConnection();
// prepare Faculty object
$Faculty = new Faculty($db);
// set Faculty_ID property of record to read
$Faculty->Emp_ID = isset($_GET['Emp_ID']) ? $_GET['Emp_ID'] : die();
// read the details of Faculty to be edited
$Faculty->readOne();
if($Faculty->L_Name!=null){
 // create array
 $Faculty_arr = array(
 "Emp_ID" => $Faculty->Emp_ID,
 "L_Name" => $Faculty->L_Name,
 "F_Name" => $Faculty->F_Name,
 "M_Name" => $Faculty->M_Name,
 "Gender" => $Faculty->Gender,
 "Dept_Code" => $Faculty->Dept_Code,
 "Dept_Description" => $Faculty->Dept_Description,
 "Email" => $Faculty->Email
 );
 // set response code - 200 OK
 http_response_code(200);
 // make it json format
 echo json_encode($Faculty_arr);
}
else{
 // set response code - 404 Not found
 http_response_code(404);
 // tell the user Faculty does not exist
 echo json_encode(array("message" => "Employee does not exist."));
}
?>