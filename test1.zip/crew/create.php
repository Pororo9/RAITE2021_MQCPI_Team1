<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers,Authorization, X-Requested-With");
// get database connection
include_once '../config/database.php';
// instantiate Faculty object
include_once '../objects/faculty.php';
$database = new Database();
$db = $database->getConnection();
$Faculty = new Faculty($db);
// get posted data
$data = json_decode(file_get_contents("php://input"));
// make sure data is not empty
if(
 !empty($data->Emp_ID) &&   
 !empty($data->L_Name) &&
 !empty($data->F_Name) &&
 !empty($data->M_Name) &&   
 !empty($data->Gender) &&
 !empty($data->Dept_Code) &&
 !empty($data->Email)
){
 // set Course property values
 $Faculty->Emp_ID = $data->Emp_ID;
 $Faculty->L_Name = $data->L_Name;
 $Faculty->F_Name = $data->F_Name;
 $Faculty->M_Name = $data->M_Name;
 $Faculty->Gender = $data->Gender;
 $Faculty->Dept_Code = $data->Dept_Code;
 $Faculty->Email = $data->Email;
 // create the Course
 if($Faculty->create()){
 // set response code - 201 created
 http_response_code(201);
 // tell the user
 echo json_encode(array("message" => "Employee was created."));
 }
 // if unable to create the Faculty, tell the user
 else{
 // set response code - 503 service unavailable
 http_response_code(503);
 // tell the user
 echo json_encode(array("message" => "Unable to create Employee."));
 }
}
// tell the user data is incomplete
else{
 // set response code - 400 bad request
 http_response_code(400);
 // tell the user
 echo json_encode(array("message" => "Unable to create Employee. Data is incomplete."));
}
?>