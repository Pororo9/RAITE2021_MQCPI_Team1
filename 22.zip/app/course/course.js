// Course list html
function readCoursesTemplate(data, keywords){
    var read_courses_html=`
    <!-- search Courses form -->
    <form id='search-course-form' action='#' method='post'>
    <div class='input-group pull-left w-30-pct'>
    <input type='text' value='` + keywords + `' name='keywords' class='form-control coursesearch-keywords' placeholder='Search course...' />
    <span class='input-group-btn'>
    <button type='submit' class='btn btn-default' type='button'>
    <span class='glyphicon glyphicon-search'></span>
    </button>
    </span>
    </div>
    </form>
    <!-- when clicked, it will load the create course form -->
    <div id='create-course' class='btn btn-primary pull-right m-b-15px create-course-button'>
    <span class='glyphicon glyphicon-plus'></span> Create Course
    </div>
    <!-- start table -->
    <table class='table table-bordered table-hover'>
    <!-- creating our table heading -->
    <tr>
    <th class='w-15-pct'>Course ID</th>
    <th class='w-15-pct'>Course Code</th>
    <th class='w-20-pct'>Course Description</th>

    <th class='w-25-pct text-align-center'>Action</th>
    </tr>`;
    // loop through returned list of data
    $.each(data.records, function(key, val) {
    // creating new table row per record
    read_courses_html+=`<tr>
    <td>` + val.Course_ID + `</td>
    <td>` + val.Course_Code + `</td>
    <td>` + val.Course_Description + `</td>
    <!-- 'action' buttons -->
    <td>
    <!-- read course button -->
    <button class='btn btn-primary m-r-10px read-one-course-button' data-id='` + val.Course_ID + `'>
    <span class='glyphicon glyphicon-eye-open'></span> Read
    </button>
    <!-- edit button -->
    <button class='btn btn-info m-r-10px update-course-button' data-id='` + val.Course_ID + `'>
    <span class='glyphicon glyphicon-edit'></span> Edit
    </button>
    <!-- delete button -->
    <button class='btn btn-danger delete-course-button' data-id='` + val.Course_ID + `'>
    <span class='glyphicon glyphicon-remove'></span> Delete
    </button>
    </td>
    </tr>`;
    });
    // end table
    // pagination
if(data.paging){
    read_courses_html+="<ul class='pagination pull-left margin-zero padding-bottom-2em'>";
    // first page
    if(data.paging.first!=""){
    read_courses_html+="<li><a data-page='" + data.paging.first + "'>First Page</a></li>";
    }
    // loop through pages
    $.each(data.paging.pages, function(key, val){
    var active_page=val.current_page=="yes" ? "class='active'" : "";
    read_courses_html+="<li " + active_page + "><a data-page='" + val.url + "'>" + val.page +
   "</a></li>";
    });
    // last page
    if(data.paging.last!=""){
    read_courses_html+="<li><a data-page='" + data.paging.last + "'>Last Page</a></li>";
    }
    read_courses_html+="</ul>";
   }
    read_courses_html+=`</table>`;
    // inject to 'page-content' of our app
    $("#page-content").html(read_courses_html);
   }