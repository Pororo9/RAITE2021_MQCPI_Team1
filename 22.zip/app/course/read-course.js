
   $(document).ready(function(){
    // show list of product on first load
    showCoursesFirstPage();
    // when a 'read Courses' button was clicked
        $(document).on('click', '.read-course-button', function(){
        showCoursesFirstPage();
        });
        // when a 'page' button was clicked
        $(document).on('click', '.pagination li', function(){
        // get json url
        var json_url=$(this).find('a').attr('data-page');
        // show list of Courses
        showCourses(json_url);
        });

   });
   function showCoursesFirstPage(){
    var json_url="http://localhost/api2/course/read_paging.php";
    showCourses(json_url);
   }
   // function to show list of Courses
   function showCourses(json_url){

        // get list of Courses from the API
        $.getJSON(json_url, function(data){

        // html for listing Courses
        readCoursesTemplate(data, "");
        
        // chage page title
        changePageTitle("Read Course");
        });
   }