$(document).ready(function(){
    // when a 'search Courses' button was clicked
    $(document).on('submit', '#search-course-form', function(){
    // get search keywords
    var keywords = $(this).find(":input[name='keywords']").val();
    // get data from the api based on search keywords
    $.getJSON("http://localhost/api2/course/search.php?s=" + keywords, function(data){
    // template in courses.js
    readCoursesTemplate(data, keywords);
    // chage page title
    changePageTitle("Search Course: " + keywords);
    });
    // prevent whole page reload
    return false;
    });
   });
   