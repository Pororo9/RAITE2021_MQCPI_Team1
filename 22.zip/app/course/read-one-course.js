$(document).ready(function(){
    // handle 'read one' button click
    $(document).on('click', '.read-one-course-button', function(){
    // course ID will be here
    // get course id
    var id = $(this).attr('data-id');
    // read course record based on given ID
    $.getJSON("http://localhost/api2/course/read_one.php?Course_ID=" + id, function(data){
    // start html
    var read_one_course_html=`
   
    <!-- when clicked, it will show the course's list -->
    <div id='read-course' class='btn btn-primary pull-right m-b-15px read-course-button'>
    <span class='glyphicon glyphicon-list'></span> Read Course
    </div>
    <!-- course data will be shown in this table -->
    <table class='table table-bordered table-hover'>
   
    <!-- course name -->
    <tr>
    <td class='w-30-pct'>Course ID</td>
    <td class='w-70-pct'>` + data.Course_ID + `</td>
    </tr>
   
    <!-- course code -->
    <tr>
    <td>Course Code</td>
    <td>` + data.Course_Code + `</td>
    </tr>

    <!-- course description -->
    <tr>
    <td>Course Description</td>
    <td>` + data.Course_Description + `</td>
    </tr>

    </table>`;
    // inject html to 'page-content' of our app
    $("#page-content").html(read_one_course_html);
   
    // chage page title
    changePageTitle("Read One Course");
    });
    });
   });