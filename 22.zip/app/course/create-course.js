$(document).ready(function(){
    // show html form when 'create product' button was clicked
    $(document).on('click', '.create-course-button', function(){
   
    // load list of course
    $.getJSON("http://localhost/api2/course/read.php", function(data){
    // build course option html
    // loop through returned list of data
    
   
    // we have our html form here where course information will be entered
    // we used the 'required' html5 property to prevent empty fields
    var create_course_html=`
   
    <!-- 'read course' button to show list of courses -->
    <div id='read-course' class='btn btn-primary pull-right m-b-15px read-course-button'>
    <span class='glyphicon glyphicon-list'></span> Read course
    </div>
    <!-- 'create course' html form -->
    <form id='create-course-form' action='#' method='post' border='0'>
    <table class='table table-hover table-responsive table-bordered'>
   
    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Course ID</td>
    <td class='w-75-pct'><input type='text' name='Course_ID' class='form-control' required
   /></td>
    </tr>

    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Course Code</td>
    <td class='w-75-pct'><input type='text' name='Course_Code' class='form-control' required
   /></td>
    </tr>

    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Course Description</td>
    <td class='w-75-pct'><input type='text' name='Course_Description' class='form-control' required
   /></td>
    </tr>

    <!-- button to submit form -->
    <tr>
    <td></td>
    <td>
    <button type='submit' class='btn btn-primary'>
    <span class='glyphicon glyphicon-plus'></span> Create Course
    </button>
    </td>
    </tr>
   
    </table>
    </form>`;
    // inject html to 'page-content' of our app
    $("#page-content").html(create_course_html);
   
    // chage page title
    changePageTitle("Create Course");
    });
    });
    // will run if create course form was submitted
    $(document).on('submit', '#create-course-form', function(){
    // get form data
    var form_data=JSON.stringify($(this).serializeObject());
    // submit form data to api
    $.ajax({
    url: "http://localhost/api2/course/create.php",
    type : "POST",
    contentType : 'application/json',
    data : form_data,
    success : function(result) {
    // course was created, go back to course list
    showCoursesFirstPage();
    },
    error: function(xhr, resp, text) {
    // show error to console
    console.log(xhr, resp, text);
    }
    });
   
    return false;
    });
   });