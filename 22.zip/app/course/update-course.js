$(document).ready(function(){
    // show html form when 'update product' button was clicked
    $(document).on('click', '.update-course-button', function(){
   
    // get course id
    var id = $(this).attr('data-id');
    // read one record based on given course id
    $.getJSON("http://localhost/api2/course/read_one.php?Course_ID=" + id, function(data){
   
    // values will be used to fill out our form
    var Course_ID = data.Course_ID;
    var Course_Code = data.Course_Code;
    var Course_Description = data.Course_Description;
    
    // load list of course
    $.getJSON("http://localhost/api2/course/read.php", function(data){
   
    // build 'course option' html
    // loop through returned list of data
    
   
    // store 'update course' html to this variable
    var update_course_html=`
    <div id='read-course' class='btn btn-primary pull-right m-b-15px read-course-button'>
    <span class='glyphicon glyphicon-list'></span> Read Course
    </div>
    <!-- build 'update course' html form -->
    <!-- we used the 'required' html5 property to prevent empty fields -->
    <form id='update-course-form' action='#' method='post' border='0'>
    <table class='table table-hover table-responsive table-bordered'>
   
    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Course Code</td>
    <td class='w-75-pct'><input value=\"` + Course_Code + `\" type='text' name='Course_Code' class='form-control' required
   /></td>
    </tr>

    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Course Description</td>
    <td class='w-75-pct'><input value=\"` + Course_Description + `\" type='text' name='Course_Description' class='form-control' required
   /></td>
    </tr>
   
   
    <!-- hidden 'course id' to identify which record to delete -->
    <td><input value=\"` + Course_ID + `\" name='Course_ID' type='hidden' /></td>
   
    <!-- button to submit form -->
    <td>
    <button type='submit' class='btn btn-info'>
    <span class='glyphicon glyphicon-edit'></span> Update Course
    </button>
    </td>
   
    </tr>
   
    </table>
    </form>`;
    // inject to 'page-content' of our app
    $("#page-content").html(update_course_html);
    
    // chage page title
    changePageTitle("Update Course");
   
    });
    });
    });
   
    // will run if 'create course' form was submitted
    $(document).on('submit', '#update-course-form', function(){
   
    // get form data
    var form_data=JSON.stringify($(this).serializeObject());
    // submit form data to api
    $.ajax({
    url: "http://localhost/api2/course/update.php",
    type : "POST",
    contentType : 'application/json',
    data : form_data,
    success : function(result) {
    // course was created, go back to courses list
    showCoursesFirstPage();
    },
    error: function(xhr, resp, text) {
    // show error to console
    console.log(xhr, resp, text);
    }
    });
   
    return false;
    });
   });