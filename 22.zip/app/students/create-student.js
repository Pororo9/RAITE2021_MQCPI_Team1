$(document).ready(function(){
    // show html form when 'create product' button was clicked
    $(document).on('click', '.create-student-button', function(){
   
    // load list of course
    $.getJSON("http://localhost/api2/course/read.php", function(data){
    // build course option html
    // loop through returned list of data
    var course_options_html=`<select name='Course_Code' class='form-control'>`;
    $.each(data.records, function(key, val){
    course_options_html+=`<option value='` + val.Course_Code + `'>` + val.Course_Code + `</option>`;
    });
    course_options_html+=`</select>`;
   
    // we have our html form here where student information will be entered
    // we used the 'required' html5 property to prevent empty fields
    var create_student_html=`
   
    <!-- 'read students' button to show list of students -->
    <div id='read-students' class='btn btn-primary pull-right m-b-15px read-students-button'>
    <span class='glyphicon glyphicon-list'></span> Read students
    </div>
    <!-- 'create student' html form -->
    <form id='create-student-form' action='#' method='post' border='0'>
    <table class='table table-hover table-responsive table-bordered'>
   
    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Student No.</td>
    <td class='w-75-pct'><input type='text' name='Stud_ID' class='form-control' required
   /></td>
    </tr>

    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Last Name</td>
    <td class='w-75-pct'><input type='text' name='L_Name' class='form-control' required
   /></td>
    </tr>

    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>First Name</td>
    <td class='w-75-pct'><input type='text' name='F_Name' class='form-control' required
   /></td>
    </tr>
   
    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Middle Name</td>
    <td class='w-75-pct'><input type='text' name='M_Name' class='form-control' required
   /></td>
    </tr>

    <td>Gender: </td>
                <td>
                    <select name="Gender">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    </select>
                </td>
   
    <!-- course 'select' field -->
    <tr>
    <td>Course Code</td>
    <td>` + course_options_html + `</td>
    </tr>

    <!-- Email field -->
    <tr>
    <td class='w-25-pct'>Email</td>
    <td class='w-75-pct'><input type='text' name='Email' class='form-control' required
   /></td>
    </tr>
   
    <!-- button to submit form -->
    <tr>
    <td></td>
    <td>
    <button type='submit' class='btn btn-primary'>
    <span class='glyphicon glyphicon-plus'></span> Create Student
    </button>
    </td>
    </tr>
   
    </table>
    </form>`;
    // inject html to 'page-content' of our app
    $("#page-content").html(create_student_html);
   
    // chage page title
    changePageTitle("Create Student");
    });
    });
    // will run if create student form was submitted
    $(document).on('submit', '#create-student-form', function(){
    // get form data
    var form_data=JSON.stringify($(this).serializeObject());
    // submit form data to api
    $.ajax({
    url: "http://localhost/api2/student/create.php",
    type : "POST",
    contentType : 'application/json',
    data : form_data,
    success : function(result) {
    // student was created, go back to students list
    showStudentsFirstPage();
    },
    error: function(xhr, resp, text) {
    // show error to console
    console.log(xhr, resp, text);
    }
    });
   
    return false;
    });
   });