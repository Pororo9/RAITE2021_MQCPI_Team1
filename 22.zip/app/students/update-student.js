$(document).ready(function(){
    // show html form when 'update product' button was clicked
    $(document).on('click', '.update-student-button', function(){
   
    // get student id
    var id = $(this).attr('data-id');
    // read one record based on given student id
    $.getJSON("http://localhost/api2/student/read_one.php?Stud_ID=" + id, function(data){
   
    // values will be used to fill out our form
    var Stud_ID = data.Stud_ID;
    var L_Name = data.L_Name;
    var F_Name = data.F_Name;
    var M_Name = data.M_Name;
    var Gender = data.Gender;
    var Course_Code = data.Course_Code;
    var Course_Description = data.Course_Description;
    var Email = data.Email;
    
    // load list of course
    $.getJSON("http://localhost/api2/course/read.php", function(data){
   
    // build 'course option' html
    // loop through returned list of data
    var course_options_html=`<select name='Course_Code' class='form-control'>`;
   
    $.each(data.records, function(key, val){
    // pre-select option is category id is the same
    if(val.id==Course_Code){ course_options_html+=`<option value='` + val.Course_Code + `'
   selected>` + val.Course_Code + `</option>`; }
   
    else{ course_options_html+=`<option value='` + val.Course_Code + `'>` + val.Course_Code + `</option>`;
   }
    });
    course_options_html+=`</select>`;
   
    // store 'update student' html to this variable
    var update_student_html=`
    <div id='read-students' class='btn btn-primary pull-right m-b-15px read-students-button'>
    <span class='glyphicon glyphicon-list'></span> Read Students
    </div>
    <!-- build 'update student' html form -->
    <!-- we used the 'required' html5 property to prevent empty fields -->
    <form id='update-student-form' action='#' method='post' border='0'>
    <table class='table table-hover table-responsive table-bordered'>
   
    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Last Name</td>
    <td class='w-75-pct'><input value=\"` + L_Name + `\" type='text' name='L_Name' class='form-control' required
   /></td>
    </tr>

    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>First Name</td>
    <td class='w-75-pct'><input value=\"` + F_Name + `\" type='text' name='F_Name' class='form-control' required
   /></td>
    </tr>
   
    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Middle Name</td>
    <td class='w-75-pct'><input value=\"` + M_Name + `\" type='text' name='M_Name' class='form-control' required
   /></td>
    </tr>

    <td>Gender: </td>
                <td>
                    <select name="Gender" value=\"` + Gender + `\">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    </select>
                </td>
   
    <!-- course 'select' field -->
    <tr>
    <td>Course Code</td>
    <td>` + course_options_html + `</td>
    </tr>

    <!-- Email field -->
    <tr>
    <td class='w-25-pct'>Email</td>
    <td class='w-75-pct'><input value=\"` + Email + `\" type='text' name='Email' class='form-control' required
   /></td>
    </tr>
   
    <!-- hidden 'student id' to identify which record to delete -->
    <td><input value=\"` + Stud_ID + `\" name='Stud_ID' type='hidden' /></td>
   
    <!-- button to submit form -->
    <td>
    <button type='submit' class='btn btn-info'>
    <span class='glyphicon glyphicon-edit'></span> Update Student
    </button>
    </td>
   
    </tr>
   
    </table>
    </form>`;
    // inject to 'page-content' of our app
    $("#page-content").html(update_student_html);
    
    // chage page title
    changePageTitle("Update Student");
   
    });
    });
    });
   
    // will run if 'create student' form was submitted
    $(document).on('submit', '#update-student-form', function(){
   
    // get form data
    var form_data=JSON.stringify($(this).serializeObject());
    // submit form data to api
    $.ajax({
    url: "http://localhost/api2/student/update.php",
    type : "POST",
    contentType : 'application/json',
    data : form_data,
    success : function(result) {
    // student was created, go back to students list
    showStudentsFirstPage();
    },
    error: function(xhr, resp, text) {
    // show error to console
    console.log(xhr, resp, text);
    }
    });
   
    return false;
    });
   });