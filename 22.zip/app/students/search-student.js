$(document).ready(function(){
    // when a 'search Students' button was clicked
    $(document).on('submit', '#search-student-form', function(){
    // get search keywords
    var keywords = $(this).find(":input[name='keywords']").val();
    // get data from the api based on search keywords
    $.getJSON("http://localhost/api2/student/search.php?s=" + keywords, function(data){
    // template in students.js
    readStudentsTemplate(data, keywords);
    // chage page title
    changePageTitle("Search Students: " + keywords);
    });
    // prevent whole page reload
    return false;
    });
   });
   