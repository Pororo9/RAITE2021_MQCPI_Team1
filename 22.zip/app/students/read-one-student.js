$(document).ready(function(){
    // handle 'read one' button click
    $(document).on('click', '.read-one-student-button', function(){
    // student ID will be here
    // get student id
    var id = $(this).attr('data-id');
    // read student record based on given ID
    $.getJSON("http://localhost/api2/student/read_one.php?Stud_ID=" + id, function(data){
    // start html
    var read_one_student_html=`
   
    <!-- when clicked, it will show the student's list -->
    <div id='read-students' class='btn btn-primary pull-right m-b-15px read-students-button'>
    <span class='glyphicon glyphicon-list'></span> Read Students
    </div>
    <!-- student data will be shown in this table -->
    <table class='table table-bordered table-hover'>
   
    <!-- student name -->
    <tr>
    <td class='w-30-pct'>Student No.</td>
    <td class='w-70-pct'>` + data.Stud_ID + `</td>
    </tr>
   
    <!-- student name -->
    <tr>
    <td>Last Name</td>
    <td>` + data.L_Name + `</td>
    </tr>
   
    <!-- student description -->
    <tr>
    <td>First Name</td>
    <td>` + data.F_Name + `</td>
    </tr>

    <!-- student name -->
    <tr>
    <td>Middle Name</td>
    <td>` + data.M_Name + `</td>
    </tr>
   
    <!-- student description -->
    <tr>
    <td>Gender</td>
    <td>` + data.Gender + `</td>
    </tr>
   
    <!-- student category name -->
    <tr>
    <td>Course Code</td>
    <td>` + data.Course_Code + `</td>
    </tr>

    <!-- student description -->
    <tr>
    <td>Course Description</td>
    <td>` + data.Course_Description + `</td>
    </tr>

    <!-- student description -->
    <tr>
    <td>Email</td>
    <td>` + data.Email + `</td>
    </tr>
   
    </table>`;
    // inject html to 'page-content' of our app
    $("#page-content").html(read_one_student_html);
   
    // chage page title
    changePageTitle("Read One Student");
    });
    });
   });