$(document).ready(function(){
    // handle 'read one' button click
    $(document).on('click', '.read-one-faculty-button', function(){
    // faculty ID will be here
    // get faculty id
    var id = $(this).attr('data-id');
    // read faculty record based on given ID
    $.getJSON("http://localhost/api2/faculty/read_one.php?Emp_ID=" + id, function(data){
    // start html
    var read_one_faculty_html=`
   
    <!-- when clicked, it will show the faculty's list -->
    <div id='read-faculty' class='btn btn-primary pull-right m-b-15px read-faculty-button'>
    <span class='glyphicon glyphicon-list'></span> Read Employees
    </div>
    <!-- faculty data will be shown in this table -->
    <table class='table table-bordered table-hover'>
   
    <!-- faculty name -->
    <tr>
    <td class='w-30-pct'>Employee ID</td>
    <td class='w-70-pct'>` + data.Emp_ID + `</td>
    </tr>
   
    <!-- faculty name -->
    <tr>
    <td>Last Name</td>
    <td>` + data.L_Name + `</td>
    </tr>
   
    <!-- faculty description -->
    <tr>
    <td>First Name</td>
    <td>` + data.F_Name + `</td>
    </tr>

    <!-- faculty name -->
    <tr>
    <td>Middle Name</td>
    <td>` + data.M_Name + `</td>
    </tr>
   
    <!-- faculty description -->
    <tr>
    <td>Gender</td>
    <td>` + data.Gender + `</td>
    </tr>
   
    <!-- faculty category name -->
    <tr>
    <td>Department Code</td>
    <td>` + data.Dept_Code + `</td>
    </tr>

    <!-- faculty description -->
    <tr>
    <td>Department Description</td>
    <td>` + data.Dept_Description + `</td>
    </tr>

    <!-- faculty description -->
    <tr>
    <td>Email</td>
    <td>` + data.Email + `</td>
    </tr>
   
    </table>`;
    // inject html to 'page-content' of our app
    $("#page-content").html(read_one_faculty_html);
   
    // chage page title
    changePageTitle("Read One Employee");
    });
    });
   });