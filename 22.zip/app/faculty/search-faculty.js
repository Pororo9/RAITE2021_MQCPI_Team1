$(document).ready(function(){
    // when a 'search facultys' button was clicked
    $(document).on('submit', '#search-faculty-form', function(){
    // get search keywords
    var keywords = $(this).find(":input[name='keywords']").val();
    // get data from the api based on search keywords
    $.getJSON("http://localhost/api2/faculty/search.php?s=" + keywords, function(data){
    // template in facultys.js
    readFacultyTemplate(data, keywords);
    // chage page title
    changePageTitle("Search Employee: " + keywords);
    });
    // prevent whole page reload
    return false;
    });
   });
   