
   $(document).ready(function(){
    // show list of product on first load
    showFacultyFirstPage();
    // when a 'read Facultys' button was clicked
        $(document).on('click', '.read-faculty-button', function(){
        showFacultyFirstPage();
        });
        // when a 'page' button was clicked
        $(document).on('click', '.pagination li', function(){
        // get json url
        var json_url=$(this).find('a').attr('data-page');
        // show list of Facultys
        showFaculty(json_url);
        });

   });
   function showFacultyFirstPage(){
    var json_url="http://localhost/api2/faculty/read_paging.php";
    showFaculty(json_url);
   }
   // function to show list of Facultys
   function showFaculty(json_url){

        // get list of Facultys from the API
        $.getJSON(json_url, function(data){

        // html for listing Facultys
        readFacultyTemplate(data, "");
        
        // chage page title
        changePageTitle("Read Employees");
        });
   }