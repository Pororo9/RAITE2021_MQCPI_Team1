$(document).ready(function(){
    // show html form when 'create product' button was clicked
    $(document).on('click', '.create-faculty-button', function(){
   
    // load list of dept
    $.getJSON("http://localhost/api2/department/read.php", function(data){
    // build dept option html
    // loop through returned list of data
    var dept_options_html=`<select name='Dept_Code' class='form-control'>`;
    $.each(data.records, function(key, val){
    dept_options_html+=`<option value='` + val.Dept_Code + `'>` + val.Dept_Code + `</option>`;
    });
    dept_options_html+=`</select>`;
   
    // we have our html form here where faculty information will be entered
    // we used the 'required' html5 property to prevent empty fields
    var create_faculty_html=`
   
    <!-- 'read faculty' button to show list of faculty -->
    <div id='read-faculty' class='btn btn-primary pull-right m-b-15px read-faculty-button'>
    <span class='glyphicon glyphicon-list'></span> Read Employees
    </div>
    <!-- 'create faculty' html form -->
    <form id='create-faculty-form' action='#' method='post' border='0'>
    <table class='table table-hover table-responsive table-bordered'>
   
    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Employee ID</td>
    <td class='w-75-pct'><input type='text' name='Emp_ID' class='form-control' required
   /></td>
    </tr>

    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Last Name</td>
    <td class='w-75-pct'><input type='text' name='L_Name' class='form-control' required
   /></td>
    </tr>

    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>First Name</td>
    <td class='w-75-pct'><input type='text' name='F_Name' class='form-control' required
   /></td>
    </tr>
   
    <!-- Stud No field -->
    <tr>
    <td class='w-25-pct'>Middle Name</td>
    <td class='w-75-pct'><input type='text' name='M_Name' class='form-control' required
   /></td>
    </tr>

    <td>Gender: </td>
                <td>
                    <select name="Gender">
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    </select>
                </td>
   
    <!-- dept 'select' field -->
    <tr>
    <td>Department Code</td>
    <td>` + dept_options_html + `</td>
    </tr>

    <!-- Email field -->
    <tr>
    <td class='w-25-pct'>Email</td>
    <td class='w-75-pct'><input type='text' name='Email' class='form-control' required
   /></td>
    </tr>
   
    <!-- button to submit form -->
    <tr>
    <td></td>
    <td>
    <button type='submit' class='btn btn-primary'>
    <span class='glyphicon glyphicon-plus'></span> Create Employee
    </button>
    </td>
    </tr>
   
    </table>
    </form>`;
    // inject html to 'page-content' of our app
    $("#page-content").html(create_faculty_html);
   
    // chage page title
    changePageTitle("Create Employee");
    });
    });
    // will run if create faculty form was submitted
    $(document).on('submit', '#create-faculty-form', function(){
    // get form data
    var form_data=JSON.stringify($(this).serializeObject());
    // submit form data to api
    $.ajax({
    url: "http://localhost/api2/faculty/create.php",
    type : "POST",
    contentType : 'application/json',
    data : form_data,
    success : function(result) {
    // faculty was created, go back to facultys list
    showFacultyFirstPage();
    },
    error: function(xhr, resp, text) {
    // show error to console
    console.log(xhr, resp, text);
    }
    });
   
    return false;
    });
   });