$(document).ready(function(){
    // show list of course on first load
   
    showLogForm();
    // when a 'read course' button was clicked
    $(document).on('submit', '#log-user-form', function(){
    // get form data
    var form_data=JSON.stringify($(this).serializeObject());
    // submit form data to api
    $.ajax({
    url: "http://localhost/api2/login.php",
    type : "POST",
    contentType : 'application/json',
    data : form_data,
    success : function(result) {
    window.location.href="home.html";
    },
    error: function(xhr, resp, text) {
    // show error to console
    console.log(xhr, resp, text);
    alert("Invalid User ID and Password!");
   
    }
    });
    return false;
    });
   });
   // function to show list of course
   function showLogForm(){
    var login_user_html=`
    <div class='container bgContainer'>
    <div>
    <form class='form-signin' id='log-user-form' name="frmLogIn" action='#' method='post'
   border='0'>
    <h3 class='form-signin-heading fontWhite'>USER LOG-IN</h3>
    <br>
    <label for='User_ID' nameclass='sr-only' class='fontWhite'>User ID</label>
    <input type='text' name='User_ID' id='User_ID' class='form-control' placeholder='User ID'
   required autofocus>
    <br>
    <label for='Password' nameclass='sr-only' class='fontWhite'>Password</label>
    <input type='password' name='Password' id='Password' class='form-control'
   placeholder='Password' required>
    <br>
    <button class='btn btn-lg btn-primary btn-block' type='submit'>Sign in</button>
    <br>
    <p align='justify' class='fontWhite'>Please login using your valid User ID and Password! In
   case of problem, please consult our system administrator.<p/>
    </form>
    </div>
    </div>`;
    $("#page-content").html(login_user_html);
   
   }