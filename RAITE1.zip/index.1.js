/**
 *
 * @revision    $Id: index.js 2012-03-24 16:21:10 Aleksey $
 * @created     2016-09-24 16:21:10
 * @category    Express Helpers
 * @package     device-uuid
 * @version     1.0.2
 * @copyright   Copyright (c) 2016-2017 - All rights reserved.
 * @license     MIT License
 * @author      Alexey Gordeyev IK <aleksej@gordejev.lv>
 * @link        http://www.gordejev.lv
 *
 */
module.exports = require('./lib/device-uuid');